package id.heru.l2tpdial;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.text.InputType;
import android.widget.Toast;

public class MainActivity extends Activity {
    private EditText serverInput, usernameInput, passwordInput, pskInput;
    private TextView status;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        layout.setPadding(pad, dp(28), pad, pad);
        scroll.addView(layout);

        TextView title = new TextView(this);
        title.setText("L2TP Dial");
        title.setTextSize(28);
        title.setTextColor(Color.rgb(25, 70, 130));
        layout.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Antarmuka awal untuk pengaturan koneksi L2TP/IPsec");
        subtitle.setTextSize(14);
        subtitle.setPadding(0, dp(6), 0, dp(20));
        layout.addView(subtitle);

        serverInput = field(layout, "Alamat server / hostname", InputType.TYPE_CLASS_TEXT);
        usernameInput = field(layout, "Username VPN", InputType.TYPE_CLASS_TEXT);
        passwordInput = field(layout, "Password VPN",
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        pskInput = field(layout, "IPsec Pre-Shared Key (PSK)",
                InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);

        Button connect = new Button(this);
        connect.setText("CONNECT");
        layout.addView(connect, matchWrap());
        connect.setOnClickListener(v -> validateInputs());

        Button disconnect = new Button(this);
        disconnect.setText("DISCONNECT");
        layout.addView(disconnect, matchWrap());
        disconnect.setOnClickListener(v -> {
            status.setText("Status: belum ada tunnel aktif pada prototipe ini.");
        });

        status = new TextView(this);
        status.setText("Status: belum terhubung");
        status.setTextSize(16);
        status.setPadding(0, dp(18), 0, dp(10));
        layout.addView(status);

        TextView note = new TextView(this);
        note.setText("Catatan: versi ini hanya antarmuka dan validasi input. Tunnel L2TP/IPsec belum diimplementasikan; tombol CONNECT tidak membuat koneksi VPN.");
        note.setTextSize(13);
        note.setTextColor(Color.DKGRAY);
        note.setPadding(0, dp(14), 0, 0);
        layout.addView(note);

        setContentView(scroll);
    }

    private EditText field(LinearLayout parent, String hint, int inputType) {
        EditText edit = new EditText(this);
        edit.setSingleLine(true);
        edit.setHint(hint);
        edit.setInputType(inputType);
        parent.addView(edit, matchWrap());
        return edit;
    }

    private void validateInputs() {
        if (serverInput.getText().toString().trim().isEmpty()
                || usernameInput.getText().toString().trim().isEmpty()
                || passwordInput.getText().length() == 0
                || pskInput.getText().length() == 0) {
            status.setText("Status: lengkapi alamat server, username, password, dan PSK.");
            Toast.makeText(this, "Semua kolom wajib diisi.", Toast.LENGTH_SHORT).show();
            return;
        }
        status.setText("Input lengkap. Tunnel belum tersedia pada versi prototipe ini.");
        Toast.makeText(this, "Validasi berhasil; koneksi VPN belum diimplementasikan.", Toast.LENGTH_LONG).show();
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
