# L2TP Dial — Android Java project scaffold

- Package: `id.heru.l2tpdial`
- Minimum Android version: Android 10 (API 29)
- Language: Java
- Build system: Gradle / Android Gradle Plugin

## Current status

This is a **UI prototype only**. It contains fields for server, username, password, and IPsec PSK plus input validation. The CONNECT button does **not** establish a VPN tunnel.

A real L2TP/IPsec client requires a working IKEv1/IPsec + L2TP + PPP implementation and careful integration with Android networking and lifecycle. Android's public APIs do not provide a simple general-purpose API to start the legacy built-in L2TP client. This project must not be treated as a functioning VPN until that implementation is completed and tested against a real server.

## Build

Open this folder in Android Studio with a compatible Android SDK installed, sync Gradle, then use **Build > Build APK(s)**. No APK is included in this archive.
